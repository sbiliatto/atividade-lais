from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/converter', methods=['POST'])
def converter():
    try:
        celsius = float(request.form['celsius'])
        fahrenheit = round((celsius * 9/5) + 32, 2)
        kelvin = round(celsius + 273.15, 2)

        return render_template('index.html', celsius=celsius, fahrenheit=fahrenheit, kelvin=kelvin)
    except ValueError:
        erro = "Por favor, insira uma temperatura válida em Celsius."
        return render_template('index.html', erro=erro)

if __name__ == '__main__':
    app.run(debug=True)