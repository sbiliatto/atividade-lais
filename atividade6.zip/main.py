from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/verificar', methods=['POST'])
def verificar():
        n1 = float(request.form['nota1'])
        n2 = float(request.form['nota2'])
        n3 = float(request.form['nota3'])

        media = round((n1 + n2 + n3) / 3, 2)
        situacao = "Aprovado" if media >= 6.0 else "Reprovado"

        return render_template('index.html', media=media, situacao=situacao)

if __name__ == '__main__':
    app.run(debug=True)