from flask import Flask, request, render_template

app = Flask (__name__)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/converter', methods= ['POST'])
def converter():
    real = float(request.form['real'])
    taxa = 5.20
    calcular = round((real / taxa),2)
    return render_template(f'index.html', real=real, calcular=calcular,)

if __name__ == '__main__':
    app.run(debug=True)